package Peoples;

import java.util.ArrayList;
import java.util.List;

public class Management {
public static void main(String[] args) {
	Teacher john=new Teacher(1, "John", 200);
	Teacher jack=new Teacher(2, "Jack", 300);
	Teacher jerry=new Teacher(3, "Jerry", 100);
	Teacher tom=new Teacher(4, "Tom", 400);
	List<Teacher> teachers=new ArrayList<>();
	teachers.add(john);
	teachers.add(jack);
	teachers.add(tom);
	teachers.add(john);
	
	Student kiran=new Student(1, "Kiran", 1);
	Student varun=new Student(2, "Varun", 2);
	Student peter=new Student(3, "Peter", 1);
	Student dom=new Student(4, "Dom", 1);
	List<Student> students=new ArrayList<>();
	students.add(peter);
	students.add(dom);
	students.add(varun);
	students.add(kiran);
	
	School svp=new School(teachers, students);
	varun.feesPay(2000);
	kiran.feesPay(1000);
	System.out.println("SVP got Earned "+svp.getTotalMoneyEarned());
	
	System.out.println("-----MAKING SCHOOL PAY SALARY------");
	
	john.recieveSalary(john.getSalary());
	System.out.println("SVP has Spent salary to"+john.getName()+"ANd how has "+svp.getTotalMoneyEarned());
	
	System.out.println(dom);
	System.out.println(john);
}
}
